<?php
//mostra cliente
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}
$sql = "SELECT * FROM cliente";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "ID: " . $row["id"] . " - Nome: " . $row["nome"] . " - Cidade: " . $row["cidade"] . " - Telefone: " . $row["telefone"] . " - Email: " . $row["email"] . "<br>";
    }
} else {
    echo "NENHUM funcionario foi encontrado!!";
}

$conn->close();
?>