<?php
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}
//modifica cliente
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $nome = $_POST['nome'];
    $cidade = $_POST['cidade'];
    $telefone = $_POST['telefone'];
    $email = $_POST['email'];
    
    $sql = "UPDATE cliente SET nome='$nome', cidade='$cidade', telefone='$telefone', email='$email' WHERE id=$id";
    
    if ($conn->query($sql) === TRUE) {
        echo "Cliente alterado com sucesso!";
    } else {
        echo "Erro: " . $sql . "<br>" . $conn->error;
    }
}

?>