<?php
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}
/*create table funcionario(
    id integer,
    nome_completo varchar(205),
    login varchar(205),
    senha varchar(205),
    primary key (id)
  ); */
//modifica funcionario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $nome_completo = $_POST['nome_completo'];
    $loginf = $_POST['loginf'];
    $senha = $_POST['senha'];
    
    $sql = "UPDATE funcionario SET nome_completo='$nome_completo', loginf='$loginf', senha='$senha' WHERE id=$id";
    
    if ($conn->query($sql) === TRUE) {
        echo "Cliente alterado com sucesso!";
    } else {
        echo "Erro: " . $sql . "<br>" . $conn->error;
    }
}

?>