<?php
//mostra funcionario
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}
$sql = "SELECT * FROM funcionario";
$result = $conn->query($sql);
/*create table funcionario(
    id integer,
    nome_completo varchar(205),
    login varchar(205),
    senha varchar(205),
    primary key (id)
  ); */
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "ID: " . $row["id"] . " - Nome_completo: " . $row["nome_completo"] . " - Login: " . $row["loginf"] . " - Senha: " . $row["senha"] . "<br>";
    }
} else {
    echo "NENHUM fu foi encontrado!!";
}

$conn->close();