<?php
/*create table funcionario(
    id integer,
    nome_completo varchar(205),
    login varchar(205),
    senha varchar(205),
    primary key (id)
  ); */
//adiciona funcionario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome_completo = $_POST['nome_completo'];
    $login = $_POST['login'];
    $senha = $_POST['senha'];
    
    $sql = "INSERT INTO funcionario (nome_completo, login, senha) VALUES ('$nome_completo', '$login', '$senha')";
    
    if ($conn->query($sql) === TRUE) {
        echo "Funcionario adicionado com sucesso!!";
    } else {
        echo "Erro: " . $sql . "<br>" . $conn->error;
    }
}
?>
?>